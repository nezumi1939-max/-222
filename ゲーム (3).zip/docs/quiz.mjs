import {countries} from './assets/countries.mjs';

export const ROUND_SIZE = 10;
export const MODES = ['flag','shape','mix'];
const openers = {flag:'NO',shape:'IT',mix:'BR'};
const lookalikeFlags = {ID:'MC',MC:'ID',RO:'TD',TD:'RO'};

export function shuffle(items, random=Math.random){
  const copy=[...items];
  for(let index=copy.length-1;index>0;index--){
    const next=Math.floor(random()*(index+1));
    [copy[index],copy[next]]=[copy[next],copy[index]];
  }
  return copy;
}

export function makeRound(mode, {intro=false,random=Math.random}={}){
  const first=intro?countries.find(country=>country.code===openers[mode]):null;
  const pool=shuffle(countries.filter(country=>country!==first),random);
  const entries=first?[first,...pool]:pool;
  const startingType=random()<.5?'flag':'shape';
  const questions=entries.slice(0,ROUND_SIZE).map((country,index)=>{
    const type=mode==='mix'?(index%2===0?startingType:startingType==='flag'?'shape':'flag'):mode;
    // Several flags are visually indistinguishable at quiz size.
    const candidates=countries.filter(item=>item!==country && (type!=='flag'||item.code!==lookalikeFlags[country.code]));
    const nearby=shuffle(candidates.filter(item=>item.region===country.region),random).slice(0,2);
    const elsewhere=shuffle(candidates.filter(item=>item.region!==country.region),random).slice(0,3-nearby.length);
    const choices=shuffle([country,...nearby,...elsewhere],random);
    return {country,choices,type,answer:null,hint:false};
  });
  return {questions,index:0,done:false};
}

export const score = round => round.questions.filter(question=>question.answer===question.country.code).length;
