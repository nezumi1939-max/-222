import {makeRound, score, ROUND_SIZE, MODES} from './quiz.mjs';

const stage=document.querySelector('#round');
const home=document.querySelector('#home');
const game=document.querySelector('#game');
const bestPanel=document.querySelector('.personal-best');
const modes=document.querySelector('#modes');
const announce=document.querySelector('#announcement');
const bestLabel=document.querySelector('#best');
const labels={flag:'国旗',shape:'国の形',mix:'ミックス'};
const key='world-country-quiz-best';
const state=new Map();
let best={};
try{
  const saved=JSON.parse(localStorage.getItem(key));
  if(saved && typeof saved==='object') best=saved;
}catch{}
let mode=null;

function visual(question, description){
  const {country,type}=question;
  return type==='flag'
    ? '<figure class="visual"><img src="./assets/flags/'+country.code.toLowerCase()+'.svg" alt="'+description+'" draggable="false"></figure>'
    : '<figure class="visual"><svg class="country-outline" viewBox="0 0 360 224" role="img" aria-label="'+description+'"><path d="'+country.outline+'"/></svg></figure>';
}
function questionView(round){
  const question=round.questions[round.index];
  const answered=question.answer!==null;
  const correct=question.answer===question.country.code;
  const flag=question.type==='flag';
  const scoreText='<span>正解 <strong>'+score(round)+'</strong></span>';
  const answers=question.choices.map((choice,index)=>{
    const isRight=answered&&choice.code===question.country.code;
    const isWrong=answered&&!isRight&&choice.code===question.answer;
    const status=isRight?'correct':isWrong?'wrong':'';
    return '<button class="answer '+status+'" data-answer="'+index+'" type="button" '+(answered?'disabled':'')+'>'
      +'<span class="answer-key" aria-hidden="true">'+(index+1)+'</span>'+choice.name
      +(status?'<span class="verdict">'+(isRight?'正解':'選択した答え')+'</span>':'')+'</button>';
  }).join('');
  const feedback=answered
    ? '<p class="feedback '+(correct?'good':'bad')+'">'+(correct?'正解！':'正解は '+question.country.name)+'<small>'+question.country.region+'</small></p>'
    : question.hint?'<p>地域は <strong>'+question.country.region+'</strong></p>'
      :'<button class="ghost" type="button" data-action="hint">ヒントを見る</button>';
  return '<div class="round-head"><span>第 <strong>'+(round.index+1)+'</strong> / '+ROUND_SIZE+' 問</span>'
    +'<progress aria-label="問題の進み具合" value="'+(round.index+Number(answered))+'" max="'+ROUND_SIZE+'"></progress>'+scoreText+'</div>'
    +'<div class="question-layout">'+visual(question,flag?'問題の国旗':'問題の国のシルエット')
    +'<div class="prompt"><h2 id="question-title" tabindex="-1">'+(flag?'この国旗はどこの国？':'この形はどこの国？')+'</h2>'
    +'<p>'+(!flag&&question.country.islandDetail?'主要な島の輪郭から国名を当ててください。':'当てはまる国名を選んでください。')+'</p><div class="answers">'+answers+'</div>'
    +'<div class="actions">'+feedback
    +(answered?'<button class="primary" type="button" data-action="next">'+(round.index+1===ROUND_SIZE?'結果を見る':'次の問題')+'</button>':'')
    +'</div></div></div>';
}
function resultView(round){
  const review=round.questions.map(question=>{
    const correct=question.answer===question.country.code;
    const chosen=question.choices.find(choice=>choice.code===question.answer);
    return '<li>'+visual(question,question.country.name+(question.type==='flag'?'の国旗':'のシルエット'))
      +'<div><strong>'+question.country.name+'</strong>'+(correct?'':'<br><small>選んだ答え '+chosen.name+'</small>')+'</div>'
      +'<span class="result-status '+(correct?'good':'bad')+'">'+(correct?'正解':'不正解')+'</span></li>';
  }).join('');
  return '<div class="result"><div class="result-top"><div><h2 id="result-title" tabindex="-1">'+labels[mode]+'の結果</h2>'
    +'<div class="result-score">'+score(round)+' / '+ROUND_SIZE+' 問正解</div></div>'
    +'<button class="primary" type="button" data-action="restart">もう一度遊ぶ</button></div><h3>答え合わせ</h3><ol class="review">'+review+'</ol></div>';
}
function render(focus){
  const onHome=mode===null;
  home.hidden=!onHome;
  game.hidden=onHome;
  bestPanel.hidden=onHome;
  if(onHome){
    for(const label of home.querySelectorAll('[data-mode-progress]')){
      const round=state.get(label.dataset.modeProgress);
      const inProgress=round&&!round.done&&(round.index>0||round.questions[0].answer!==null);
      label.hidden=!inProgress;
      label.textContent=inProgress?'第'+(round.index+1)+'問から再開':'';
    }
    if(focus) home.querySelector(focus)?.focus();
    return;
  }
  const round=state.get(mode);
  bestLabel.textContent=Number.isInteger(best[mode])?best[mode]+' / '+ROUND_SIZE:'—';
  for(const button of modes.querySelectorAll('[data-mode]')){
    button.setAttribute('aria-pressed',String(button.dataset.mode===mode));
  }
  stage.innerHTML=round.done?resultView(round):questionView(round);
  if(focus) stage.querySelector(focus)?.focus({preventScroll:true});
}

function selectAnswer(index){
  const round=state.get(mode);
  const question=round.questions[round.index];
  if(round.done || question.answer!==null || !question.choices[index]) return;
  question.answer=question.choices[index].code;
  announce.textContent=question.answer===question.country.code?'正解。'+question.country.name:'正解は '+question.country.name+' です。';
  render('[data-action=next]');
}
function next(){
  const round=state.get(mode);
  if(round.done || round.questions[round.index].answer===null) return;
  if(round.index+1<ROUND_SIZE){
    round.index++;
    render('#question-title');
    return;
  }
  round.done=true;
  best[mode]=Math.max(best[mode]??0,score(round));
  try{localStorage.setItem(key,JSON.stringify(best));}catch{}
  render('#result-title');
}

function chooseMode(event){
  const pressed=event.target.closest('[data-mode]');
  if(!pressed || !MODES.includes(pressed.dataset.mode) || mode===pressed.dataset.mode) return;
  const fromHome=mode===null;
  mode=pressed.dataset.mode;
  if(!state.has(mode)||fromHome&&state.get(mode).done) state.set(mode,makeRound(mode,{intro:!state.has(mode)}));
  render(state.get(mode).done?'#result-title':'#question-title');
  if(fromHome) window.scrollTo(0,0);
}
function showHome(){
  if(mode===null) return;
  mode=null;
  render('#home-title');
  window.scrollTo(0,0);
}
home.addEventListener('click',chooseMode);
modes.addEventListener('click',chooseMode);
document.querySelector('#home-button').addEventListener('click',showHome);
document.querySelector('#back-home').addEventListener('click',showHome);
stage.addEventListener('click', event=>{
  const button=event.target.closest('button');
  if(!button || button.disabled) return;
  if(button.dataset.answer!==undefined) selectAnswer(Number(button.dataset.answer));
  else if(button.dataset.action==='next') next();
  else if(button.dataset.action==='restart'){
    state.set(mode,makeRound(mode));
    render('#question-title');
    stage.scrollIntoView({block:'nearest'});
  }else if(button.dataset.action==='hint'){
    const round=state.get(mode);
    const question=round.questions[round.index];
    question.hint=true;
    announce.textContent='ヒント。地域は '+question.country.region+' です。';
    render('[data-answer="0"]');
  }
});
document.addEventListener('keydown', event=>{
  if(mode===null||event.altKey||event.ctrlKey||event.metaKey||event.repeat||!['1','2','3','4'].includes(event.key)) return;
  selectAnswer(Number(event.key)-1);
});
render();
