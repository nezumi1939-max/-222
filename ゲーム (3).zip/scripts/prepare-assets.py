"""Generate quiz art from Natural Earth GeoJSON and a flag-icons tarball."""
import json
import math
from pathlib import Path
import sys
import tarfile

root = Path(__file__).resolve().parents[1]
out = root / "docs" / "assets"
(out / "flags").mkdir(parents=True, exist_ok=True)
countries = [row.split("\t") for row in (root / "scripts/countries.tsv").read_text().splitlines()]
features = json.loads(Path(sys.argv[1]).read_text())["features"]
by_code = {f["properties"]["ISO3166-1-Alpha-2"]: f["geometry"] for f in features}

# Use the main geographic area for countries whose distant islands would shrink
# the recognizable silhouette. Keep the separately listed nearby islands.
views = {"US":(-130,23,-64,51), "FR":(-7,41,10,52), "NO":(3,57,32,72),
         "NZ":(165,-48,179,-33), "CL":(-77,-57,-65,-16),
         "PT":(-10,35,-5,43), "ES":(-11,35,5,45),
         "AU":(110,-45,155,-9), "GB":(-9,49,3,61)}

# Dispersed island chains can become unreadable at a single zoom level.
# Use their largest mapped island and label the crop in the quiz.
island_detail = {"KI", "MH", "FM", "TV", "MV", "TO"}

def unwrap(rings):
    longitudes = sorted({x % 360 for ring in rings for x, _ in ring})
    gaps = zip(longitudes, longitudes[1:] + [longitudes[0] + 360])
    west, east = max(gaps, key=lambda gap: gap[1] - gap[0])
    pivot = ((west + east) / 2) % 360
    return [[(pivot + (x - pivot) % 360, y) for x, y in ring] for ring in rings]

def area(points):
    return abs(sum(x*y2-x2*y for (x,y),(x2,y2) in zip(points,points[1:]))) / 2

def simplify(points, tolerance=.48):
    if len(points) < 3:
        return points
    a, b = points[0], points[-1]
    dx, dy = b[0]-a[0], b[1]-a[1]
    length = dx*dx+dy*dy
    furthest, distance = 0, 0
    for index, (x,y) in enumerate(points[1:-1], 1):
        position = max(0,min(1,((x-a[0])*dx+(y-a[1])*dy)/length)) if length else 0
        gap = (x-a[0]-position*dx)**2+(y-a[1]-position*dy)**2
        if gap > distance:
            furthest, distance = index, gap
    if distance <= tolerance*tolerance:
        return [a,b]
    return simplify(points[:furthest+1],tolerance)[:-1]+simplify(points[furthest:],tolerance)

def outline(code):
    geom = by_code[code]
    polygons = geom["coordinates"] if geom["type"] == "MultiPolygon" else [geom["coordinates"]]
    rings = [polygon[0] for polygon in polygons]
    if code in views:
        west, south, east, north = views[code]
        rings = [ring for ring in rings if west <= ring[0][0] <= east and south <= ring[0][1] <= north]
    rings = unwrap(rings)
    rings.sort(key=area,reverse=True)
    if code in island_detail:
        rings = rings[:1]
    rings = [r for r in rings if area(r) > area(rings[0])*.0015][:35]
    points = [point for ring in rings for point in ring]
    left, right = min(p[0] for p in points), max(p[0] for p in points)
    bottom, top = min(p[1] for p in points), max(p[1] for p in points)
    cos = math.cos(math.radians((top+bottom)/2))
    scale = min(300/((right-left)*cos), 193/(top-bottom))
    output = []
    for ring in rings:
        pts = [(180+(x-(left+right)/2)*cos*scale, 112-(y-(top+bottom)/2)*scale) for x,y in ring]
        pts = simplify(pts)
        if len(pts) >= 4:
            output.append("M"+" ".join(f"{x:.1f},{y:.1f}" for x,y in pts[:-1])+"Z")
    if not output:
        raise ValueError(code)
    return "".join(output)

with tarfile.open(sys.argv[2], "r:gz") as flags:
    (out / "flag-icons-LICENSE.txt").write_bytes(flags.extractfile("package/LICENSE").read())
    data = []
    for code,name,region in countries:
        flag = flags.extractfile(f"package/flags/4x3/{code.lower()}.svg").read()
        (out / "flags" / f"{code.lower()}.svg").write_bytes(flag)
        entry = dict(code=code, name=name, region=region, outline=outline(code))
        if code in island_detail:
            entry["islandDetail"] = True
        data.append(entry)
(out / "countries.mjs").write_text("export const countries = "+json.dumps(data, ensure_ascii=False,separators=(",",":"))+";\n")
print(f"Prepared {len(data)} countries in both formats.")
