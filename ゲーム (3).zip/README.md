# 世界の国当てクイズ

国旗・国のシルエット・ミックスから選ぶ日本語の4択クイズです。ホームでモードを選ぶと始まります。各モード10問で、ベストスコアはブラウザ内に保存します。出題対象は国連加盟193か国とオブザーバー2か国の計195か国です。輪郭は本土周辺を中心に簡略化し、島々が広く離れる一部の国は主要な島を拡大表示します。

## パソコンで遊ぶ

ZIPをすべて展開して、フォルダ内の「ゲーム.html」をダブルクリックしてください。ネット接続や追加のソフトは不要です。

ソースの開発時には `python3 -m http.server 8000 -d docs` を実行して http://localhost:8000/ を開きます。

## GitHub Pages

公開元に `main` ブランチの `/docs` を指定します。

## 出典

- 地理データは [Natural Earth](https://www.naturalearthdata.com/) をもとにした [geo-countries](https://github.com/datasets/geo-countries/blob/master/data/countries.geojson) の GeoJSON。
- 国旗は [flag-icons 7.3.2](https://github.com/lipis/flag-icons/tree/v7.3.2) の 4:3 SVG。同梱の MIT ライセンスを参照。

画像を作り直すときは、この順に GeoJSON と flag-icons の npm tarball を `python3 scripts/prepare-assets.py` に渡します。
